"use client"

import app from "../Server/index"

export default function SyntheticV0PageForDeployment() {
  return <app />
}