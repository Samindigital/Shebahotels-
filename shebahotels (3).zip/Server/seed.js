import mongoose from "mongoose"
import dotenv from "dotenv"
import Hotel from "./models/Hotel.js"
import User from "./models/User.js"
import SpecialDeal from "./models/SpecialDeal.js"

// Load environment variables
dotenv.config()

// Connect to MongoDB
const mongoURI = process.env.MONGODB_URI || "mongodb://localhost:27017/shebahotels"

const seedDatabase = async () => {
  try {
    await mongoose.connect(mongoURI)
    console.log("Connected to MongoDB")

    // Clear existing data
    await Hotel.deleteMany({})
    await User.deleteMany({})
    await SpecialDeal.deleteMany({})

    // Sample hotel data
    const hotels = [
      {
        name: "Luxury Palace Hotel",
        description: "A luxurious 5-star hotel with stunning views and exceptional service.",
        location: "Addis Ababa, Ethiopia",
        price: 250,
        amenities: ["wifi", "pool", "spa", "gym", "restaurant"],
        images: ["hotel1.jpg", "hotel1-room.jpg", "hotel1-pool.jpg"],
        rooms: [
          { type: "Standard", price: 250, quantity: 20 },
          { type: "Deluxe", price: 350, quantity: 15 },
          { type: "Suite", price: 500, quantity: 5 },
        ],
        averageRating: 4.7,
      },
      {
        name: "Sheba Comfort Inn",
        description: "Comfortable and affordable accommodation in the heart of the city.",
        location: "Nairobi, Kenya",
        price: 120,
        amenities: ["wifi", "breakfast", "parking"],
        images: ["hotel2.jpg", "hotel2-room.jpg", "hotel2-lobby.jpg"],
        rooms: [
          { type: "Standard", price: 120, quantity: 30 },
          { type: "Family", price: 180, quantity: 10 },
        ],
        averageRating: 4.2,
      },
      {
        name: "Royal Oasis Resort",
        description: "An exclusive beachfront resort with private villas and world-class amenities.",
        location: "Zanzibar, Tanzania",
        price: 380,
        amenities: ["wifi", "pool", "spa", "beach", "restaurant", "bar"],
        images: ["hotel3.jpg", "hotel3-beach.jpg", "hotel3-villa.jpg"],
        rooms: [
          { type: "Garden Villa", price: 380, quantity: 12 },
          { type: "Beach Villa", price: 520, quantity: 8 },
          { type: "Royal Villa", price: 750, quantity: 3 },
        ],
        averageRating: 4.9,
      },
    ]

    // Insert sample hotels
    const createdHotels = await Hotel.insertMany(hotels)
    console.log(`${createdHotels.length} hotels created`)

    // Create admin user
    const adminUser = new User({
      name: "Admin User",
      email: "admin@shebahotels.com",
      password: "admin123",
      isAdmin: true,
    })
    await adminUser.save()
    console.log("Admin user created")

    // Create regular user
    const regularUser = new User({
      name: "Test User",
      email: "user@shebahotels.com",
      password: "user123",
      isAdmin: false,
    })
    await regularUser.save()
    console.log("Regular user created")

    // Create special deal
    const specialDeal = new SpecialDeal({
      title: "Summer Special",
      description: "Enjoy 20% off on all bookings for summer vacation!",
      discount: 20,
      code: "SUMMER20",
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days from now
      active: true,
      applicableHotels: createdHotels.map((hotel) => hotel._id),
      image: "summer-deal.jpg",
    })
    await specialDeal.save()
    console.log("Special deal created")

    console.log("Database seeded successfully")
  } catch (error) {
    console.error("Error seeding database:", error)
  } finally {
    await mongoose.disconnect()
    console.log("Disconnected from MongoDB")
  }
}

seedDatabase()

