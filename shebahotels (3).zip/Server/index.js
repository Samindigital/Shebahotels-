import express from "express"
import mongoose from "mongoose"
import path from "path"
import { fileURLToPath } from "url"
import cors from "cors"
import dotenv from "dotenv"
import crypto from "crypto"

// Load environment variables (if .env exists)
dotenv.config()

// Generate a random JWT secret if not provided
if (!process.env.JWT_SECRET) {
  process.env.JWT_SECRET = crypto.randomBytes(64).toString("hex")
  console.log("Generated random JWT_SECRET for development")
}

// Set default PORT
const PORT = process.env.PORT || 3000

// Import models
import Hotel from "./models/Hotel.js"
import User from "./models/User.js"
import Booking from "./models/Booking.js"
import SpecialDeal from "./models/SpecialDeal.js"

// Server Setup
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const app = express()

// Middleware
app.use(cors())
app.use(express.json())

// Create a public directory for static files if it doesn't exist
const publicPath = path.join(__dirname, "public")
app.use(express.static(publicPath))

// API Endpoints
app.get("/api/hotels", async (req, res) => {
  try {
    const hotels = await Hotel.find()
    res.json(hotels)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.get("/api/hotels/:id", async (req, res) => {
  try {
    const hotel = await Hotel.findById(req.params.id)
    if (!hotel) {
      return res.status(404).json({ error: "Hotel not found" })
    }
    res.json(hotel)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.get("/api/search", async (req, res) => {
  try {
    const { query } = req.query
    const results = await Hotel.find({
      $or: [{ name: { $regex: query, $options: "i" } }, { location: { $regex: query, $options: "i" } }],
    })
    res.json(results)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

app.get("/api/special-deals", async (req, res) => {
  try {
    const deals = await SpecialDeal.find({ active: true })
    res.json(deals)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// User authentication routes
app.post("/api/users/register", async (req, res) => {
  try {
    const user = new User(req.body)
    await user.save()
    const token = await user.generateAuthToken()
    res.status(201).json({ user, token })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.post("/api/users/login", async (req, res) => {
  try {
    const user = await User.findByCredentials(req.body.email, req.body.password)
    const token = await user.generateAuthToken()
    res.json({ user, token })
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

// Booking routes
app.post("/api/bookings", async (req, res) => {
  try {
    const booking = new Booking(req.body)
    await booking.save()
    res.status(201).json(booking)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
})

app.get("/api/bookings/user/:userId", async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.params.userId }).populate("hotel")
    res.json(bookings)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Add a health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Server is running" })
})

// Serve Frontend - this will be handled by the parent website
app.get("*", (req, res) => {
  res.status(200).json({ message: "ShebaHotels API is running" })
})

// Connect to MongoDB with fallback to MongoDB Atlas free tier
const connectDB = async () => {
  try {
    // Use provided MONGODB_URI or fallback to MongoDB Atlas free tier
    const mongoURI =
      process.env.MONGODB_URI ||
      "mongodb+srv://shebahotels:shebahotels123@cluster0.mongodb.net/shebahotels?retryWrites=true&w=majority"

    const options = {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
    }

    await mongoose.connect(mongoURI, options)
    console.log("MongoDB Connected")

    // Start server after successful DB connection
    if (process.env.NODE_ENV !== "production") {
      app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`)
        console.log(`Server URL: http://localhost:${PORT}`)
      })
    }

    // Add sample data if database is empty
    const hotelsCount = await Hotel.countDocuments()
    if (hotelsCount === 0) {
      console.log("Adding sample data to database...")
      await addSampleData()
    }
  } catch (err) {
    console.error("MongoDB connection error:", err.message)

    // If we can't connect to MongoDB, start server anyway for API testing
    if (process.env.NODE_ENV !== "production") {
      app.listen(PORT, () => {
        console.log(`Server running on port ${PORT} (without database)`)
        console.log(`Server URL: http://localhost:${PORT}`)
      })
    }
  }
}

// Function to add sample data
const addSampleData = async () => {
  try {
    // Sample hotel data
    const hotels = [
      {
        name: "Luxury Palace Hotel",
        description: "A luxurious 5-star hotel with stunning views and exceptional service.",
        location: "Addis Ababa, Ethiopia",
        price: 250,
        amenities: ["wifi", "pool", "spa", "gym", "restaurant"],
        images: ["hotel1.jpg", "hotel1-room.jpg", "hotel1-pool.jpg"],
        rooms: [
          { type: "Standard", price: 250, quantity: 20 },
          { type: "Deluxe", price: 350, quantity: 15 },
          { type: "Suite", price: 500, quantity: 5 },
        ],
        averageRating: 4.7,
      },
      {
        name: "Sheba Comfort Inn",
        description: "Comfortable and affordable accommodation in the heart of the city.",
        location: "Nairobi, Kenya",
        price: 120,
        amenities: ["wifi", "breakfast", "parking"],
        images: ["hotel2.jpg", "hotel2-room.jpg", "hotel2-lobby.jpg"],
        rooms: [
          { type: "Standard", price: 120, quantity: 30 },
          { type: "Family", price: 180, quantity: 10 },
        ],
        averageRating: 4.2,
      },
      {
        name: "Royal Oasis Resort",
        description: "An exclusive beachfront resort with private villas and world-class amenities.",
        location: "Zanzibar, Tanzania",
        price: 380,
        amenities: ["wifi", "pool", "spa", "beach", "restaurant", "bar"],
        images: ["hotel3.jpg", "hotel3-beach.jpg", "hotel3-villa.jpg"],
        rooms: [
          { type: "Garden Villa", price: 380, quantity: 12 },
          { type: "Beach Villa", price: 520, quantity: 8 },
          { type: "Royal Villa", price: 750, quantity: 3 },
        ],
        averageRating: 4.9,
      },
    ]

    // Insert sample hotels
    await Hotel.insertMany(hotels)

    // Create admin user
    const adminUser = new User({
      name: "Admin User",
      email: "admin@shebahotels.com",
      password: "admin123",
      isAdmin: true,
    })
    await adminUser.save()

    // Create special deal
    const specialDeal = new SpecialDeal({
      title: "Summer Special",
      description: "Enjoy 20% off on all bookings for summer vacation!",
      discount: 20,
      code: "SUMMER20",
      startDate: new Date(),
      endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 days from now
      active: true,
      applicableHotels: [],
      image: "summer-deal.jpg",
    })
    await specialDeal.save()

    console.log("Sample data added successfully")
  } catch (error) {
    console.error("Error adding sample data:", error)
  }
}

// For Vercel deployment, we don't need to call app.listen()
// as Vercel will handle that for us
if (process.env.NODE_ENV !== "production") {
  // Start the server only in development
  connectDB()
} else {
  // In production, just connect to the database
  connectDB()
}

// Export the Express API for Vercel
export default app

