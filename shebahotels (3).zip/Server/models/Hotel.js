import mongoose from "mongoose"

const hotelSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    description: { type: String, required: true },
    location: { type: String, required: true },
    price: { type: Number, required: true },
    amenities: [String],
    images: [String],
    rooms: [
      {
        type: { type: String, required: true },
        price: { type: Number, required: true },
        quantity: { type: Number, required: true },
      },
    ],
    ratings: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        value: { type: Number, required: true, min: 1, max: 5 },
        comment: String,
      },
    ],
    averageRating: { type: Number, default: 0 },
  },
  { timestamps: true },
)

hotelSchema.methods.updateAverageRating = async function () {
  const hotel = await this.model("Hotel").findById(this._id).populate("ratings")
  if (hotel.ratings.length === 0) {
    this.averageRating = 0
    return
  }
  const sum = hotel.ratings.reduce((acc, rating) => acc + rating.value, 0)
  this.averageRating = sum / hotel.ratings.length
  await this.save()
}

const Hotel = mongoose.model("Hotel", hotelSchema)
export default Hotel

