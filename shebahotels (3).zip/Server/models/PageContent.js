import mongoose from "mongoose"

const pageContentSchema = new mongoose.Schema(
  {
    pageName: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    content: { type: String, required: true },
    metaDescription: String,
    keywords: [String],
    images: [String],
    styles: {
      primaryColor: { type: String, default: "#003580" },
      secondaryColor: { type: String, default: "#0071c2" },
      fontFamily: { type: String, default: "Arial, sans-serif" },
    },
  },
  { timestamps: true },
)

const PageContent = mongoose.model("PageContent", pageContentSchema)
export default PageContent

