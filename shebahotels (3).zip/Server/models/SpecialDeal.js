import mongoose from "mongoose"

const specialDealSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    discount: { type: Number, required: true },
    code: { type: String, required: true, unique: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    active: { type: Boolean, default: true },
    applicableHotels: [{ type: mongoose.Schema.Types.ObjectId, ref: "Hotel" }],
    image: String,
  },
  { timestamps: true },
)

const SpecialDeal = mongoose.model("SpecialDeal", specialDealSchema)
export default SpecialDeal

