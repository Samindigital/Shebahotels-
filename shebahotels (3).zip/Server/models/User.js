import mongoose from "mongoose"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    isAdmin: { type: Boolean, default: false },
    tokens: [
      {
        token: { type: String, required: true },
      },
    ],
  },
  { timestamps: true },
)

userSchema.methods.toJSON = function () {
  const user = this.toObject()
  delete user.password
  delete user.tokens
  return user
}

userSchema.methods.generateAuthToken = async function () {
  // Use the JWT_SECRET from environment or the default one generated in index.js
  const token = jwt.sign({ _id: this._id.toString() }, process.env.JWT_SECRET)
  this.tokens = this.tokens.concat({ token })
  await this.save()
  return token
}

userSchema.statics.findByCredentials = async (email, password) => {
  const User = mongoose.model("User")
  const user = await User.findOne({ email })
  if (!user) throw new Error("Unable to login")

  const isMatch = await bcrypt.compare(password, user.password)
  if (!isMatch) throw new Error("Unable to login")

  return user
}

userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 8)
  }
  next()
})

const User = mongoose.model("User", userSchema)
export default User

