// This script handles integration with parent websites when embedded
;(() => {
  // Check if we're in an iframe
  const isEmbedded = window.self !== window.top

  if (isEmbedded) {
    // Parse query parameters
    const urlParams = new URLSearchParams(window.location.search)
    const apiUrl = urlParams.get("apiUrl")

    // Update config if apiUrl is provided
    if (apiUrl) {
      window.shebaConfig = window.shebaConfig || {}
      window.shebaConfig.apiUrl = apiUrl
    }

    // Send resize messages to parent
    function sendResizeMessage() {
      const height = document.body.scrollHeight
      window.parent.postMessage(
        {
          type: "shebahotels:resize",
          height: height,
        },
        "*",
      )
    }

    // Listen for resize events
    window.addEventListener("resize", sendResizeMessage)

    // Send initial resize after load
    window.addEventListener("load", sendResizeMessage)

    // Listen for navigation messages from parent
    window.addEventListener("message", (event) => {
      if (event.data.type === "shebahotels:navigate") {
        window.location.hash = event.data.path
      }
    })

    // Add embedded class to body
    document.body.classList.add("embedded")
  }
})()

