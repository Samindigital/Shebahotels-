// API configuration
const config = {
  // API base URL - use relative path for integration with other websites
  apiUrl: "/api",

  // Default image path - use relative path
  defaultImagePath: "/uploads/",

  // Authentication token storage key with unique prefix to avoid conflicts
  tokenKey: "shebahotels_auth_token",

  // User data storage key with unique prefix
  userKey: "shebahotels_user",
}

export default config

