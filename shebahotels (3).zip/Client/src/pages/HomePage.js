"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import axios from "axios"
import { Container, Typography, Button, Grid, Card, CardMedia, CardContent, CardActions } from "@material-ui/core"
import { DateRange, Star } from "@material-ui/icons"
import DateRangePicker from "../components/DateRangePicker"
import SearchBar from "../components/SearchBar"
import config from "../config"
import "./HomePage.css"

const HomePage = ({ user }) => {
  const [hotels, setHotels] = useState([])
  const [specialDeals, setSpecialDeals] = useState([])
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState([null, null])
  const [startDate, endDate] = dateRange
  const navigate = useNavigate()

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [hotelsRes, dealsRes] = await Promise.all([
          axios.get(`${config.apiUrl}/hotels?limit=4`),
          axios.get(`${config.apiUrl}/special-deals`),
        ])
        setHotels(hotelsRes.data)
        setSpecialDeals(dealsRes.data)
      } catch (err) {
        console.error("Error fetching data:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const handleSearch = (destination) => {
    navigate(`/hotels?destination=${destination}`)
  }

  const handleBookNow = (hotelId) => {
    navigate(`/hotels/${hotelId}`)
  }

  // Function to get image URL with fallback
  const getImageUrl = (imagePath) => {
    if (!imagePath) return "/default-hotel.jpg"

    // If image path is a full URL, use it directly
    if (imagePath.startsWith("http")) return imagePath

    // Otherwise, use the configured path
    return `${config.defaultImagePath}${imagePath}`
  }

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="home-page">
      <div className="hero-section" style={{ backgroundColor: "var(--primary-color)" }}>
        <Container maxWidth="md">
          <Typography variant="h2" component="h1" gutterBottom style={{ color: "white" }}>
            Find your perfect stay with Queen Sheba's blessing 👑
          </Typography>
          <Typography variant="h5" component="h2" gutterBottom style={{ color: "white" }}>
            Discover amazing hotels at unbeatable prices
          </Typography>

          <div className="search-container">
            <SearchBar onSearch={handleSearch} />
            <div className="date-picker-container">
              <DateRangePicker
                ranges={[
                  {
                    startDate,
                    endDate,
                    key: "selection",
                  },
                ]}
                onChange={(item) => setDateRange([item.selection.startDate, item.selection.endDate])}
              />
              <Button variant="contained" color="secondary" startIcon={<DateRange />} style={{ marginLeft: "10px" }}>
                {startDate && endDate
                  ? `${startDate.toLocaleDateString()} - ${endDate.toLocaleDateString()}`
                  : "Select Dates"}
              </Button>
            </div>
          </div>
        </Container>
      </div>

      <Container maxWidth="lg" className="section">
        <Typography variant="h4" component="h2" gutterBottom>
          Featured Hotels
        </Typography>
        <Grid container spacing={4}>
          {hotels.map((hotel) => (
            <Grid item key={hotel._id} xs={12} sm={6} md={3}>
              <Card className="hotel-card">
                <CardMedia component="img" height="140" image={getImageUrl(hotel.images[0])} alt={hotel.name} />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="h3">
                    {hotel.name}
                  </Typography>
                  <Typography variant="body2" color="textSecondary" component="p">
                    {hotel.location}
                  </Typography>
                  <div className="rating">
                    <Star color="secondary" />
                    <Typography variant="body2">{hotel.averageRating || "New"}</Typography>
                  </div>
                  <Typography variant="h6" component="p">
                    ${hotel.price} <span className="per-night">per night</span>
                  </Typography>
                </CardContent>
                <CardActions>
                  <Button size="small" color="primary" onClick={() => handleBookNow(hotel._id)}>
                    Book Now
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {specialDeals.length > 0 && (
        <div className="deals-section" style={{ backgroundColor: "var(--secondary-color)" }}>
          <Container maxWidth="lg" className="section">
            <Typography variant="h4" component="h2" gutterBottom style={{ color: "white" }}>
              Special Deals
            </Typography>
            <Grid container spacing={4}>
              {specialDeals.map((deal) => (
                <Grid item key={deal._id} xs={12} sm={6} md={4}>
                  <Card className="deal-card">
                    <CardMedia
                      component="img"
                      height="140"
                      image={deal.image ? getImageUrl(deal.image) : "/default-deal.jpg"}
                      alt={deal.title}
                    />
                    <CardContent>
                      <Typography gutterBottom variant="h5" component="h3">
                        {deal.title}
                      </Typography>
                      <Typography variant="body2" color="textSecondary" component="p">
                        {deal.description}
                      </Typography>
                      <Typography variant="h6" component="p" style={{ color: "var(--primary-color)" }}>
                        {deal.discount}% OFF - Use code: {deal.code}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Container>
        </div>
      )}
    </div>
  )
}

export default HomePage

