"use client"

import { useState } from "react"
import { useNavigate, useLocation, Link } from "react-router-dom"
import axios from "axios"
import { Container, Typography, TextField, Button, Paper, Grid } from "@material-ui/core"
import { Alert } from "@material-ui/lab"
import "./LoginPage.css"

const LoginPage = ({ onLogin }) => {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from || "/"

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await axios.post("/api/users/login", { email, password })
      localStorage.setItem("token", response.data.token)
      localStorage.setItem("user", JSON.stringify(response.data.user))

      if (onLogin) {
        onLogin(response.data.user)
      }

      navigate(from, { replace: true })
    } catch (err) {
      setError(err.response?.data?.error || "Login failed. Please check your credentials.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Container maxWidth="sm" className="login-page">
      <Paper elevation={3} className="login-paper">
        <Typography variant="h4" component="h1" align="center" gutterBottom>
          Login to ShebaHotels
        </Typography>

        {error && (
          <Alert severity="error" className="login-alert">
            {error}
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <TextField
            label="Email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            fullWidth
            required
            margin="normal"
            variant="outlined"
          />

          <TextField
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            fullWidth
            required
            margin="normal"
            variant="outlined"
          />

          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            size="large"
            disabled={loading}
            className="login-button"
          >
            {loading ? "Logging in..." : "Login"}
          </Button>
        </form>

        <Grid container justifyContent="center" className="login-links">
          <Grid item>
            <Typography variant="body2">
              Don't have an account? <Link to="/register">Register</Link>
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  )
}

export default LoginPage

