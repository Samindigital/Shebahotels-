"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import axios from "axios"
import {
  Container,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  Paper,
  TextField,
  Rating,
  Divider,
} from "@material-ui/core"
import { Person, KingBed, Bathtub, Wifi, AcUnit, Restaurant, Pool } from "@material-ui/icons"
import DateRangePicker from "../components/DateRangePicker"
import config from "../config"
import "./HotelDetails.css"

const HotelDetails = ({ user }) => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [hotel, setHotel] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [dateRange, setDateRange] = useState([null, null])
  const [startDate, endDate] = dateRange
  const [guests, setGuests] = useState(1)
  const [selectedRoom, setSelectedRoom] = useState(null)
  const [review, setReview] = useState({ rating: 5, comment: "" })

  useEffect(() => {
    const fetchHotel = async () => {
      try {
        const res = await axios.get(`${config.apiUrl}/hotels/${id}`)
        setHotel(res.data)
      } catch (err) {
        setError(err.response?.data?.error || "Failed to fetch hotel details")
      } finally {
        setLoading(false)
      }
    }
    fetchHotel()
  }, [id])

  // Function to get image URL with fallback
  const getImageUrl = (imagePath) => {
    if (!imagePath) return "/default-hotel.jpg"

    // If image path is a full URL, use it directly
    if (imagePath.startsWith("http")) return imagePath

    // Otherwise, use the configured path
    return `${config.defaultImagePath}${imagePath}`
  }

  const handleBookNow = async () => {
    if (!user) {
      navigate("/login", { state: { from: `/hotels/${id}` } })
      return
    }

    if (!startDate || !endDate || !selectedRoom) {
      alert("Please select dates and a room type")
      return
    }

    try {
      const bookingData = {
        hotel: id,
        roomType: selectedRoom.type,
        checkIn: startDate,
        checkOut: endDate,
        guests,
        totalPrice: selectedRoom.price * Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)),
      }
      await axios.post(`${config.apiUrl}/bookings`, bookingData)
      navigate("/my-bookings")
    } catch (err) {
      alert(err.response?.data?.error || "Booking failed")
    }
  }

  const handleSubmitReview = async () => {
    if (!user) {
      navigate("/login", { state: { from: `/hotels/${id}` } })
      return
    }

    try {
      await axios.post(`${config.apiUrl}/hotels/${id}/ratings`, review)
      setReview({ rating: 5, comment: "" })
      const res = await axios.get(`${config.apiUrl}/hotels/${id}`)
      setHotel(res.data)
    } catch (err) {
      alert(err.response?.data?.error || "Failed to submit review")
    }
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div>{error}</div>

  return (
    <Container maxWidth="lg" className="hotel-details">
      <Typography variant="h3" component="h1" gutterBottom>
        {hotel.name}
      </Typography>
      <Typography variant="subtitle1" gutterBottom>
        {hotel.location}
      </Typography>
      
      <div className="hotel-header">
        <div className="rating">
          <Rating value={hotel.averageRating || 0} precision={0.5} readOnly />
          <Typography variant="body1">{hotel.averageRating?.toFixed(1) || 'New'}</Typography>
        </div>
        <Typography variant="h5" className="price">
          ${hotel.price} <span className="per-night">per night</span>
        </Typography>
      </div>
      
      <div className="hotel-images">
        {hotel.images && hotel.images.length > 0 ? (
          <Grid container spacing={2}>
            <Grid item xs={12} md={8}>
              <img 
                src={getImageUrl(hotel.images[0]) || "/placeholder.svg"} 
                alt={hotel.name} 
                className="main-image" 
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Grid container spacing={2}>
                {hotel.images.slice(1, 3).map((img, index) => (
                  <Grid item xs={6} md={12} key={index}>
                    <img 
                      src={getImageUrl(img) || "/placeholder.svg"} 
                      alt={`${hotel.name} ${index + 1}`} 
                      className="thumbnail-image" 
                    />
                  </Grid>
                ))}
              </Grid>
            </Grid>
          </Grid>
        ) : (
          <img src="/default-hotel.jpg" alt={hotel.name} className="main-image" />
        )}
      </div>
      
      <Grid container spacing={4} style={{ marginTop: '20px' }}>
        <Grid item xs={12} md={8}>
          <Paper className="section-paper">
            <Typography variant="h5" gutterBottom>Description</Typography>
            <Typography variant="body1">{hotel.description}</Typography>
          </Paper>
          
          <Paper className="section-paper">
            <Typography variant="h5" gutterBottom>Amenities</Typography>
            <Grid container spacing={2}>
              {hotel.amenities.map((amenity, index) => (
                <Grid item xs={6} sm={4} key={index}>
                  <div className="amenity-item">
                    {amenity === 'wifi' && <Wifi />}
                    {amenity === 'pool' && <Pool />}
                    {amenity === 'restaurant' && <Restaurant />}
                    {amenity === 'ac' && <AcUnit />}
                    {amenity === 'spa' && <Bathtub />}
                    <Typography variant="body2">{amenity}</Typography>
                  </div>
                </Grid>
              ))}
            </Grid>
          </Paper>
          
          <Paper className="section-paper">
            <Typography variant="h5" gutterBottom>Reviews</Typography>
            {hotel.ratings && hotel.ratings.length > 0 ? (
              hotel.ratings.map((rating, index) => (
                <div key={index} className="review-item">
                  <div className="review-header">
                    <Rating value={rating.value} readOnly size="small" />
                    <Typography variant="body2">{new Date(rating.createdAt).toLocaleDateString()}</Typography>
                  </div>
                  <Typography variant="body1">{rating.comment}</Typography>
                  {index < hotel.ratings.length - 1 && <Divider />}
                </div>
              ))
            ) : (
              <Typography variant="body2">No reviews yet. Be the first to review!</Typography>
            )}
            
            {user && (
              <div className="add-review">
                <Typography variant="h6" gutterBottom>Add Your Review</Typography>
                <Rating
                  value={review.rating}
                  onChange={(event, newValue) => {
                    setReview(prev => ({ ...prev, rating: newValue }));
                  }}
                />
                <TextField
                  label="Your Review"
                  multiline
                  rows={4}
                  value={review.comment}
                  onChange={(e) => setReview(prev => ({ ...prev, comment: e.target.value }))}
                  fullWidth
                  margin="normal"
                  variant="outlined"
                />
                <Button 
                  variant="contained" 
                  color="primary"
                  onClick={handleSubmitReview}
                >
                  Submit Review
                </Button>
              </div>
            )}
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper className="booking-form">
            <Typography variant="h5" gutterBottom>Book Now</Typography>
            
            <div className="form-group">
              <Typography variant="body1">Select Dates</Typography>
              <DateRangePicker
                ranges={[{
                  startDate,
                  endDate,
                  key: 'selection'
                }]}
                onChange={item => setDateRange([item.selection.startDate, item.selection.endDate])}
              />
            </div>
            
            <div className="form-group">
              <Typography variant="body1">Guests</Typography>
              <div className="guests-input">
                <Button 
                  size="small" 
                  variant="outlined"
                  onClick={() => setGuests(prev => Math.max(1, prev - 1))}
                >
                  -
                </Button>
                <Typography variant="body1">{guests}</Typography>
                <Button 
                  size="small" 
                  variant="outlined"\
                  onClick={() => setGuests(prev => prev + 1))}
                >
                  +
                </Button>
              </div>
            </div>
            
            <div className="form-group">
              <Typography variant="body1">Select Room Type</Typography>
              <Grid container spacing={2}>
                {hotel.rooms.map((room, index) => (
                  <Grid item xs={12} key={index}>
                    <Card 
                      className={`room-card ${selectedRoom === room ? 'selected' : ''}`}
                      onClick={() => setSelectedRoom(room)}
                    >
                      <CardContent>
                        <Typography variant="h6">{room.type}</Typography>
                        <Typography variant="body2">
                          <KingBed fontSize="small" /> {room.type === 'Suite' ? 'King Bed' : 'Queen Bed'}
                        </Typography>
                        <Typography variant="body2">
                          <Person fontSize="small" /> Max {room.type === 'Family' ? 4 : room.type === 'Suite' ? 3 : 2} guests
                        </Typography>
                        <Typography variant="h6" className="room-price">
                          ${room.price} <span className="per-night">per night</span>
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </div>
            
            {startDate && endDate && selectedRoom && (
              <div className="price-summary">
                <div className="price-row">
                  <Typography variant="body1">
                    ${selectedRoom.price} x {Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24))} nights
                  </Typography>
                  <Typography variant="body1">
                    ${selectedRoom.price * Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24))}
                  </Typography>
                </div>
                
                <div className="price-row total">
                  <Typography variant="body1" className="bold">Total</Typography>
                  <Typography variant="body1" className="bold">
                    ${selectedRoom.price * Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24))}
                  </Typography>
                </div>
              </div>
            )}
            
            <Button 
              variant="contained" 
              color="primary"
              fullWidth
              size="large"
              onClick={handleBookNow}
              disabled={!startDate || !endDate || !selectedRoom}
            >
              Book Now
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  )
}

export default HotelDetails

