import { Link } from "react-router-dom"
import { Container, Grid, Typography, Link as MuiLink } from "@material-ui/core"
import "./Footer.css"

const Footer = () => {
  return (
    <footer className="footer" style={{ backgroundColor: "var(--primary-color)", color: "white" }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" gutterBottom>
              ShebaHotels.com
            </Typography>
            <Typography variant="body2">
              Find the perfect hotel for your next trip with Queen Sheba's blessing.
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" gutterBottom>
              Explore
            </Typography>
            <MuiLink component={Link} to="/hotels" color="inherit" display="block" gutterBottom>
              Hotels
            </MuiLink>
            <MuiLink component={Link} to="/about" color="inherit" display="block" gutterBottom>
              About Us
            </MuiLink>
            <MuiLink component={Link} to="/contact" color="inherit" display="block" gutterBottom>
              Contact
            </MuiLink>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" gutterBottom>
              Legal
            </Typography>
            <MuiLink component={Link} to="/terms" color="inherit" display="block" gutterBottom>
              Terms & Conditions
            </MuiLink>
            <MuiLink href="#" color="inherit" display="block" gutterBottom>
              Privacy Policy
            </MuiLink>
            <MuiLink href="#" color="inherit" display="block" gutterBottom>
              Cookie Policy
            </MuiLink>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h6" gutterBottom>
              Contact Us
            </Typography>
            <Typography variant="body2" gutterBottom>
              Email: contact@shebahotels.com
            </Typography>
            <Typography variant="body2" gutterBottom>
              Phone: +1 (234) 567-890
            </Typography>
          </Grid>
        </Grid>
        <Typography variant="body2" align="center" style={{ marginTop: "20px" }}>
          © {new Date().getFullYear()} ShebaHotels.com - All rights reserved
        </Typography>
      </Container>
    </footer>
  )
}

export default Footer

