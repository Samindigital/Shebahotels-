"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { AppBar, Toolbar, Typography, Button, IconButton, Menu, MenuItem, Avatar, Badge } from "@material-ui/core"
import { DateRange, Person, Menu as MenuIcon, Notifications } from "@material-ui/icons"
import "./Header.css"

const Header = ({ user, onLogout }) => {
  const [anchorEl, setAnchorEl] = useState(null)
  const navigate = useNavigate()

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const handleLogout = () => {
    handleClose()
    onLogout()
    navigate("/")
  }

  return (
    <AppBar position="static" className="header" style={{ backgroundColor: "var(--primary-color)" }}>
      <Toolbar>
        <div className="header-left">
          <IconButton edge="start" color="inherit" aria-label="menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className="header-title">
            <Link to="/" style={{ textDecoration: "none", color: "inherit", display: "flex", alignItems: "center" }}>
              <span style={{ fontFamily: "cursive", marginRight: "5px" }}>👑</span>
              ShebaHotels.com
            </Link>
          </Typography>
        </div>

        <div className="header-center">
          <Button color="inherit" startIcon={<DateRange />}>
            Stays
          </Button>
          <Button color="inherit">Flights</Button>
          <Button color="inherit">Car Rentals</Button>
          <Button color="inherit">Attractions</Button>
        </div>

        <div className="header-right">
          {user ? (
            <>
              <IconButton color="inherit">
                <Badge badgeContent={3} color="secondary">
                  <Notifications />
                </Badge>
              </IconButton>
              <IconButton
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
              >
                <Avatar src="/default-avatar.jpg" alt={user.name} />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{ vertical: "top", horizontal: "right" }}
                keepMounted
                transformOrigin={{ vertical: "top", horizontal: "right" }}
                open={Boolean(anchorEl)}
                onClose={handleClose}
              >
                <MenuItem
                  onClick={() => {
                    handleClose()
                    navigate("/my-bookings")
                  }}
                >
                  My Bookings
                </MenuItem>
                <MenuItem onClick={handleLogout}>Logout</MenuItem>
                {user.isAdmin && (
                  <MenuItem
                    onClick={() => {
                      handleClose()
                      window.location.href = "http://localhost:3001"
                    }}
                  >
                    Admin Dashboard
                  </MenuItem>
                )}
              </Menu>
            </>
          ) : (
            <>
              <Button color="inherit" component={Link} to="/register">
                Register
              </Button>
              <Button color="inherit" component={Link} to="/login" startIcon={<Person />}>
                Sign in
              </Button>
            </>
          )}
        </div>
      </Toolbar>
    </AppBar>
  )
}

export default Header

