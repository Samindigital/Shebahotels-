"use client"

import { useState } from "react"
import axios from "axios"
import config from "../config"

export default function Search() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleSearch = async () => {
    if (!query.trim()) return

    setLoading(true)
    setError(null)

    try {
      const response = await axios.get(`${config.apiUrl}/search?query=${query}`)
      setResults(response.data)
    } catch (error) {
      console.error("Search error:", error)
      setError("Failed to search. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="search-box">
      <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search hotels..." />
      <button onClick={handleSearch} disabled={loading}>
        {loading ? "Searching..." : "Search"}
      </button>

      {error && <div className="error-message">{error}</div>}

      {results.length > 0 && (
        <div className="search-results">
          {results.map((hotel) => (
            <div key={hotel._id} className="search-result-item">
              {hotel.name} - {hotel.location}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

