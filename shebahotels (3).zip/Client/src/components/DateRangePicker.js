"use client"

import { useState } from "react"
import { DateRange } from "react-date-range"
import "react-date-range/dist/styles.css"
import "react-date-range/dist/theme/default.css"
import { Paper, Popover } from "@material-ui/core"
import "./DateRangePicker.css"

const DateRangePicker = ({ ranges, onChange }) => {
  const [anchorEl, setAnchorEl] = useState(null)

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  const open = Boolean(anchorEl)
  const id = open ? "date-range-popover" : undefined

  return (
    <div className="date-range-picker">
      <button aria-describedby={id} onClick={handleClick} className="date-picker-button">
        {ranges[0].startDate && ranges[0].endDate
          ? `${ranges[0].startDate.toLocaleDateString()} - ${ranges[0].endDate.toLocaleDateString()}`
          : "Select Dates"}
      </button>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
      >
        <Paper>
          <DateRange
            editableDateInputs={true}
            onChange={(item) => {
              onChange(item)
              if (item.selection.startDate !== item.selection.endDate) {
                handleClose()
              }
            }}
            moveRangeOnFirstSelection={false}
            ranges={ranges}
          />
        </Paper>
      </Popover>
    </div>
  )
}

export default DateRangePicker

