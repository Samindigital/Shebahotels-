"use client"

import { useState, useEffect } from "react"
import { Routes, Route } from "react-router-dom"
import axios from "axios"
import "./App.css"
import config from "./src/config"

// Components
import Header from "./src/components/Header"
import Footer from "./src/components/Footer"

// Pages
import HomePage from "./src/pages/HomePage"
import HotelDetails from "./src/pages/HotelDetails"
import LoginPage from "./src/pages/LoginPage"

// Configure axios defaults
axios.defaults.baseURL = config.apiUrl

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem(config.userKey)
    const token = localStorage.getItem(config.tokenKey)

    if (storedUser && token) {
      setUser(JSON.parse(storedUser))
      // Set default auth header for all requests
      axios.defaults.headers.common["Authorization"] = `Bearer ${token}`
    }

    setLoading(false)
  }, [])

  const handleLogin = (userData) => {
    setUser(userData)
    localStorage.setItem(config.userKey, JSON.stringify(userData))
  }

  const handleLogout = () => {
    localStorage.removeItem(config.userKey)
    localStorage.removeItem(config.tokenKey)
    delete axios.defaults.headers.common["Authorization"]
    setUser(null)
  }

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="app">
      <Header user={user} onLogout={handleLogout} />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<HomePage user={user} />} />
          <Route path="/hotels/:id" element={<HotelDetails user={user} />} />
          <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
          {/* Add more routes as needed */}
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App

