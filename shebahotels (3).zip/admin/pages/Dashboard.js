"use client"

import { useState } from "react"
import axios from "axios"

export default function Dashboard() {
  const [searchTerm, setSearchTerm] = useState("")
  const [hotels, setHotels] = useState([])

  const handleSearch = async () => {
    const res = await axios.get(`http://localhost:5000/api/search?query=${searchTerm}`)
    setHotels(res.data)
  }

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search hotels..."
      />
      <button onClick={handleSearch}>Search</button>

      <div className="hotel-list">
        {hotels.map((hotel) => (
          <div key={hotel._id}>{hotel.name}</div>
        ))}
      </div>
    </div>
  )
}

