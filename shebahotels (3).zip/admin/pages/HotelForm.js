"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import axios from "axios"
import {
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  Grid,
  InputLabel,
  Select,
  MenuItem,
  FormControl,
  Chip,
  CircularProgress,
} from "@material-ui/core"
import { Add as AddIcon } from "@material-ui/icons"
import ImageUpload from "../components/ImageUpload"
import RoomForm from "../components/RoomForm"
import "./HotelForm.css"

const HotelForm = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [hotel, setHotel] = useState({
    name: "",
    description: "",
    location: "",
    price: 0,
    amenities: [],
    images: [],
    rooms: [],
  })
  const [loading, setLoading] = useState(!!id)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState(null)
  const [newAmenity, setNewAmenity] = useState("")

  const amenitiesOptions = ["wifi", "pool", "gym", "spa", "restaurant", "bar", "parking", "ac", "breakfast", "pets"]

  useEffect(() => {
    if (id) {
      const fetchHotel = async () => {
        try {
          const res = await axios.get(`/hotels/${id}`)
          setHotel(res.data)
        } catch (err) {
          setError(err.response?.data?.error || "Failed to fetch hotel")
        } finally {
          setLoading(false)
        }
      }
      fetchHotel()
    }
  }, [id])

  const handleChange = (e) => {
    const { name, value } = e.target
    setHotel((prev) => ({ ...prev, [name]: value }))
  }

  const handleAmenityAdd = () => {
    if (newAmenity && !hotel.amenities.includes(newAmenity)) {
      setHotel((prev) => ({ ...prev, amenities: [...prev.amenities, newAmenity] }))
      setNewAmenity("")
    }
  }

  const handleAmenityRemove = (amenity) => {
    setHotel((prev) => ({
      ...prev,
      amenities: prev.amenities.filter((a) => a !== amenity),
    }))
  }

  const handleImagesUpload = (files) => {
    const newImages = files.map((file) => file.name) // In a real app, you'd upload to server
    setHotel((prev) => ({ ...prev, images: [...prev.images, ...newImages] }))
  }

  const handleImageRemove = (image) => {
    setHotel((prev) => ({
      ...prev,
      images: prev.images.filter((img) => img !== image),
    }))
  }

  const handleRoomAdd = (room) => {
    setHotel((prev) => ({ ...prev, rooms: [...prev.rooms, room] }))
  }

  const handleRoomUpdate = (index, updatedRoom) => {
    setHotel((prev) => {
      const updatedRooms = [...prev.rooms]
      updatedRooms[index] = updatedRoom
      return { ...prev, rooms: updatedRooms }
    })
  }

  const handleRoomRemove = (index) => {
    setHotel((prev) => {
      const updatedRooms = [...prev.rooms]
      updatedRooms.splice(index, 1)
      return { ...prev, rooms: updatedRooms }
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      if (id) {
        await axios.patch(`/hotels/${id}`, hotel)
      } else {
        await axios.post("/hotels", hotel)
      }
      navigate("/hotels")
    } catch (err) {
      setError(err.response?.data?.error || "Failed to save hotel")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="loading-center">
        <CircularProgress />
      </div>
    )
  }

  if (error) {
    return (
      <Container>
        <Typography color="error">{error}</Typography>
      </Container>
    )
  }

  return (
    <Container maxWidth="lg" className="hotel-form">
      <Typography variant="h4" gutterBottom>
        {id ? "Edit Hotel" : "Add New Hotel"}
      </Typography>

      <Paper elevation={3} className="form-paper">
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <TextField
                label="Hotel Name"
                name="name"
                value={hotel.name}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
              />
              <TextField
                label="Location"
                name="location"
                value={hotel.location}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
              />
              <TextField
                label="Price per night ($)"
                name="price"
                type="number"
                value={hotel.price}
                onChange={handleChange}
                fullWidth
                required
                margin="normal"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                label="Description"
                name="description"
                value={hotel.description}
                onChange={handleChange}
                fullWidth
                required
                multiline
                rows={4}
                margin="normal"
              />
            </Grid>

            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Amenities
              </Typography>
              <div className="amenities-container">
                <FormControl fullWidth margin="normal">
                  <InputLabel>Add Amenity</InputLabel>
                  <Select value={newAmenity} onChange={(e) => setNewAmenity(e.target.value)} displayEmpty>
                    <MenuItem value="" disabled>
                      Select amenity
                    </MenuItem>
                    {amenitiesOptions.map((opt) => (
                      <MenuItem key={opt} value={opt} disabled={hotel.amenities.includes(opt)}>
                        {opt}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                <Button
                  variant="outlined"
                  color="primary"
                  startIcon={<AddIcon />}
                  onClick={handleAmenityAdd}
                  disabled={!newAmenity}
                >
                  Add
                </Button>
              </div>
              <div className="chips-container">
                {hotel.amenities.map((amenity) => (
                  <Chip
                    key={amenity}
                    label={amenity}
                    onDelete={() => handleAmenityRemove(amenity)}
                    className="amenity-chip"
                  />
                ))}
              </div>
            </Grid>

            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Images
              </Typography>
              <ImageUpload onUpload={handleImagesUpload} existingImages={hotel.images} onRemove={handleImageRemove} />
            </Grid>

            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Rooms
              </Typography>
              <RoomForm
                rooms={hotel.rooms}
                onAdd={handleRoomAdd}
                onUpdate={handleRoomUpdate}
                onRemove={handleRoomRemove}
              />
            </Grid>

            <Grid item xs={12} className="form-actions">
              <Button variant="contained" color="primary" type="submit" disabled={saving}>
                {saving ? <CircularProgress size={24} /> : "Save Hotel"}
              </Button>
              <Button variant="outlined" onClick={() => navigate("/hotels")}>
                Cancel
              </Button>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Container>
  )
}

export default HotelForm

