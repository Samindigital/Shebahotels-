"use client"

import { useState } from "react"
import { Outlet, Link, useNavigate } from "react-router-dom"
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Avatar,
  Box,
} from "@material-ui/core"
import {
  Dashboard,
  Hotel,
  Book,
  People,
  Description,
  LocalOffer,
  Menu as MenuIcon,
  ExitToApp,
} from "@material-ui/icons"
import "./AdminLayout.css"

const AdminLayout = ({ user, onLogout }) => {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const navigate = useNavigate()

  const menuItems = [
    { text: "Dashboard", icon: <Dashboard />, path: "/dashboard" },
    { text: "Hotels", icon: <Hotel />, path: "/hotels" },
    { text: "Bookings", icon: <Book />, path: "/bookings" },
    { text: "Users", icon: <People />, path: "/users" },
    { text: "Page Content", icon: <Description />, path: "/page-content" },
    { text: "Special Deals", icon: <LocalOffer />, path: "/special-deals" },
  ]

  const handleLogout = () => {
    onLogout()
    navigate("/login")
  }

  return (
    <div className="admin-layout">
      <AppBar position="fixed" className="admin-header">
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={() => setDrawerOpen(true)}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className="admin-title">
            ShebaHotels Admin 👑
          </Typography>
          <div className="admin-user">
            <Avatar src="/default-avatar.jpg" alt={user.name} />
            <Typography variant="body1" style={{ marginLeft: "10px" }}>
              {user.name}
            </Typography>
            <IconButton color="inherit" onClick={handleLogout}>
              <ExitToApp />
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>

      <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <div className="drawer-paper">
          <Box p={2} className="drawer-header">
            <Typography variant="h6">ShebaHotels</Typography>
          </Box>
          <List>
            {menuItems.map((item) => (
              <ListItem button key={item.text} component={Link} to={item.path} onClick={() => setDrawerOpen(false)}>
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
          </List>
        </div>
      </Drawer>

      <main className="admin-content">
        <Toolbar /> {/* This is for spacing under the fixed AppBar */}
        <Outlet />
      </main>
    </div>
  )
}

export default AdminLayout

