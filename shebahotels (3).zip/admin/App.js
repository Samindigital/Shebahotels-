"use client"

import { useEffect, useState } from "react"
import "./App.css"
import Search from "./components/Search"

function App() {
  const [hotels, setHotels] = useState([])

  useEffect(() => {
    fetch("/api/hotels")
      .then((res) => res.json())
      .then((data) => setHotels(data))
  }, [])

  return (
    <div className="app">
      <header>
        <h1>👑 ShebaHotels.com</h1>
        <Search />
      </header>
      <main>
        {hotels.map((hotel) => (
          <div key={hotel._id} className="hotel-card">
            <h2>{hotel.name}</h2>
            <p>{hotel.location}</p>
          </div>
        ))}
      </main>
    </div>
  )
}

export default function App() {
  return (
    <div>
      <h1>🔒 ShebaHotels Admin Panel</h1>
      <p>Manage hotels and bookings</p>
    </div>
  )
}

