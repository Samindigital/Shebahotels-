# Deploying ShebaHotels to Vercel

This guide will help you deploy the ShebaHotels application to Vercel.

## Prerequisites

- A Vercel account (sign up at [vercel.com](https://vercel.com))
- Git repository with your ShebaHotels code

## Deployment Steps

### 1. Prepare Your Project

Make sure your project structure is as follows:

