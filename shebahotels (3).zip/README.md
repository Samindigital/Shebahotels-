# ShebaHotels - Hotel Booking Platform

ShebaHotels is a full-stack hotel booking platform built with the MERN stack (MongoDB, Express, React, Node.js).

## Features

- Browse and search for hotels
- View hotel details, rooms, and amenities
- User authentication (register/login)
- Book hotel rooms
- Special deals and promotions
- Admin dashboard for hotel management

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- MongoDB (local installation or MongoDB Atlas account)

### Installation

1. Clone the repository:

